# READVERSE 2.0 — Complete Deployment Guide
## Beginner-Friendly · Free Hosting Only · Step by Step

---

## 📁 FOLDER STRUCTURE (Where every file goes)

```
readverse-backend/
├── server.js                        ← Main entry point
├── package.json                     ← Dependencies
├── .env                             ← Your secrets (never commit!)
├── .env.example                     ← Template for .env
├── .gitignore                       ← Files Git should ignore
│
├── public/                          ← Frontend (served as static files)
│   ├── index.html                   ← The READVERSE UI
│   ├── sw.js                        ← Service worker (PWA)
│   ├── manifest.json                ← PWA manifest
│   └── icons/                       ← App icons (192x192, 512x512)
│
└── src/
    ├── aggregators/
    │   └── rssAggregator.js         ← Fetches all RSS feeds
    ├── engines/
    │   ├── summarizerEngine.js      ← Local AI summarization (TF-IDF)
    │   ├── categorizationEngine.js  ← Auto-classifies articles
    │   ├── sentimentEngine.js       ← Positive/negative detection
    │   ├── credibilityEngine.js     ← Fake news scoring
    │   └── trendingEngine.js        ← Trending score calculator
    ├── models/
    │   ├── Article.js               ← MongoDB article schema
    │   └── User.js                  ← MongoDB user schema
    ├── routes/
    │   ├── articles.js              ← GET /api/articles
    │   ├── categories.js            ← GET /api/categories + search
    │   ├── auth.js                  ← POST /api/auth/login etc.
    │   ├── bookmarks.js             ← Bookmarks + admin + digest
    │   └── sitemap.js               ← /sitemap.xml
    ├── middleware/
    │   ├── requireAuth.js           ← JWT verification
    │   ├── errorHandler.js          ← Global error catcher
    │   └── botDetect.js             ← Bot protection
    └── utils/
        ├── database.js              ← MongoDB connection
        └── cache.js                 ← In-memory cache
```

---

## 🗄️ STEP 1 — Get a Free MongoDB Database

1. Go to **https://mongodb.com/atlas**
2. Click **"Try Free"** → create account
3. Choose **Free Tier (M0)** → pick any region
4. Click **"Connect"** → **"Connect your application"**
5. Copy the connection string — looks like:
   `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/`
6. Add database name at the end: `readverse`
   Final: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/readverse`
7. **SAVE THIS** — you'll need it as `MONGODB_URI`

---

## 💻 STEP 2 — Local Development Setup

### Prerequisites
- Install **Node.js 18+** from https://nodejs.org (download LTS version)
- Install **Git** from https://git-scm.com

### Setup commands (copy-paste one by one):
```bash
# Clone or create your project folder
mkdir readverse && cd readverse

# Copy all the generated files into this folder (from the delivered code)
# Then run:

npm install

# Create your .env file
cp .env.example .env

# Edit .env with your values (use any text editor):
# - Set MONGODB_URI to your Atlas connection string
# - Set JWT_SECRET to any long random string (e.g.: myS3cr3tK3y2024ReadverseApp!)
# - Set PORT=3000

# Start the server
npm run dev
```

Open **http://localhost:3000** — you should see READVERSE with live news!

---

## 🚀 STEP 3A — Deploy on Render (Recommended — Completely Free)

Render gives you a free Node.js server + auto-deploy from GitHub.

1. Push your code to GitHub:
   ```bash
   git init
   git add .
   git commit -m "READVERSE 2.0 launch"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/readverse.git
   git push -u origin main
   ```

2. Go to **https://render.com** → Sign up (free)

3. Click **"New +"** → **"Web Service"**

4. Connect your GitHub repo

5. Settings:
   - **Name:** readverse
   - **Environment:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Instance Type:** Free

6. Click **"Advanced"** → **"Add Environment Variable"**:
   - `MONGODB_URI` → your Atlas connection string
   - `JWT_SECRET` → your secret key
   - `NODE_ENV` → `production`
   - `ALLOWED_ORIGINS` → `https://your-app.onrender.com`

7. Click **"Create Web Service"** → Wait ~3 minutes for deploy

8. Your app is live at: `https://your-app-name.onrender.com` 🎉

**Note:** Free Render servers sleep after 15 min of inactivity.
To keep it awake, use **https://uptimerobot.com** (free) to ping your `/health` endpoint every 5 minutes.

---

## 🚀 STEP 3B — Deploy on Railway (Alternative)

1. Go to **https://railway.app** → Login with GitHub
2. Click **"New Project"** → **"Deploy from GitHub repo"**
3. Select your readverse repo
4. Railway auto-detects Node.js and deploys
5. Go to **Variables** tab → add `MONGODB_URI`, `JWT_SECRET`, `NODE_ENV=production`
6. Go to **Settings** → **Networking** → Generate a domain
7. Done! ~$5 free credit per month (enough for light traffic)

---

## 🌐 STEP 3C — Frontend Only on Netlify (Static deployment)

If you want to host just the frontend (`public/index.html`) separately:

1. Go to **https://netlify.com** → Sign up
2. Drag and drop your `public/` folder onto the Netlify dashboard
3. Your frontend is live instantly!
4. Update the `API` variable in `index.html` to point to your Render/Railway backend URL:
   ```js
   // In index.html, change this line:
   const API = window.location.hostname === 'localhost'
     ? 'http://localhost:3000/api'
     : 'https://YOUR-RENDER-APP.onrender.com/api'; // ← your backend
   ```

---

## 📱 STEP 4 — Mobile Deployment via Termux + GitHub

Run the READVERSE backend directly on your Android phone!

### Install Termux:
1. Download **Termux** from F-Droid: https://f-droid.org/packages/com.termux/
   (Don't use Play Store version — it's outdated)

### Setup in Termux:
```bash
# Update packages
pkg update && pkg upgrade -y

# Install Node.js and Git
pkg install nodejs git -y

# Clone your repo
git clone https://github.com/YOUR_USERNAME/readverse.git
cd readverse

# Install dependencies
npm install

# Create .env
cp .env.example .env
nano .env  # Edit with your MongoDB URI and JWT secret (Ctrl+X to save)

# Start the server
node server.js
```

### Keep it running (background):
```bash
# Install tmux to keep server alive when Termux is minimized
pkg install tmux -y
tmux new -s readverse
node server.js
# Press Ctrl+B then D to detach (server keeps running)
# To reattach: tmux attach -t readverse
```

### Access from your phone browser:
- Open **http://localhost:3000** in Chrome on the same phone

### Expose to internet (optional — free):
```bash
# Install cloudflared for free tunnel
pkg install cloudflared -y
cloudflared tunnel --url http://localhost:3000
# It gives you a public URL like: https://xxx.trycloudflare.com
```

---

## 🔧 STEP 5 — Mobile Deployment via Acode

Acode is a code editor for Android that can run Node.js via Termux integration.

1. Install **Acode** from Play Store
2. Install **Termux** (F-Droid version)
3. In Termux: `pkg install nodejs git -y`
4. Open Acode → open your project folder from Termux storage
5. Use Acode's built-in terminal to run `node server.js`
6. Edit files directly in Acode, re-run in terminal

---

## 📋 STEP 6 — .gitignore (Important!)

Create a `.gitignore` file to protect your secrets:

```
node_modules/
.env
*.log
logs/
cache/
.DS_Store
```

---

## 🔒 STEP 7 — Make Admin Account

After deploying, make yourself an admin:

1. Sign up normally through the READVERSE UI
2. In MongoDB Atlas, go to your `users` collection
3. Find your user document
4. Edit it: set `isAdmin: true`
5. Save

Now you can access `/api/admin/stats` with your JWT token.

---

## ⚡ PERFORMANCE TIPS FOR FREE HOSTING

1. **MongoDB Atlas free tier** = 512MB storage. With 5000 articles × ~2KB = ~10MB. You're fine.

2. **Render free tier** sleeps after 15 min. Add UptimeRobot to ping `/health` every 5 min.

3. **RSS rate limiting**: The aggregator has a 1-second delay between batches. Some feeds block frequent requests. If a source fails, it just skips silently.

4. **Breaking news sources**: Some RSS feeds don't include breaking flags. The system auto-detects based on keywords like "breaking", "urgent", "alert".

5. **Tamil language**: RSS feeds in Tamil use Unicode. The system passes them through as-is. TTS uses `ta-IN` voice on supported browsers.

---

## 🐛 TROUBLESHOOTING

| Problem | Solution |
|---------|----------|
| `MONGODB_URI not set` | Check your `.env` file has `MONGODB_URI=mongodb+srv://...` |
| No articles loading | Check Render logs for RSS fetch errors. Some feeds need VPN. |
| `CORS blocked` | Add your frontend URL to `ALLOWED_ORIGINS` in `.env` |
| JWT expired error | Log out and log back in. Token lasts 7 days. |
| Render app sleeping | Add UptimeRobot free monitor for your `/health` URL |
| Termux permission denied | Run `termux-setup-storage` first |
| No weather showing | Allow location permission in browser |

---

## 📈 SCALING TIPS (When you grow)

- **MongoDB Atlas M2** ($9/mo) for 2GB + dedicated tier
- **Render Starter** ($7/mo) to keep server always-on
- **Redis** (free tier at upstash.com) to replace node-cache for multi-instance
- **Cloudflare** (free) as CDN and DDoS protection — just point your domain there
- **Google AdSense** — add to `index.html` once you have traffic (see Revenue section)

---

## 💰 REVENUE SYSTEM (Optional)

### Google AdSense:
Add this before `</head>` in `index.html` once AdSense approves your site:
```html
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossorigin="anonymous"></script>
```
Add ad slots inside `.feed-col` div.

### Affiliate Links:
Amazon affiliate links inside article cards for product-related news.
```js
// In cardHTML(), add for tech articles:
if (a.category === 'Technology') {
  // append affiliate banner
}
```

### Premium Subscriptions:
Use Razorpay (India, free to start) or Stripe for paid tiers:
- Free: 20 articles/day + basic AI summary
- Premium ₹99/mo: unlimited + advanced features + no ads

---

## ✅ CHECKLIST — Before Going Live

- [ ] MongoDB Atlas created and URI saved
- [ ] `.env` file filled with real values
- [ ] `npm install` ran successfully
- [ ] `node server.js` starts without errors
- [ ] `http://localhost:3000` shows live news (not demo data!)
- [ ] Pushed to GitHub
- [ ] Deployed on Render/Railway
- [ ] UptimeRobot pinging `/health` every 5 min
- [ ] Added to Google Search Console for SEO
- [ ] (Optional) PWA icons added to `public/icons/`
